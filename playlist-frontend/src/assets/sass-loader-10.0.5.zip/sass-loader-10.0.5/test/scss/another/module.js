// ./another/module.js: The sass-loader should not try to import that. scss, sass and css extensions should be preferred.
// See https://github.com/webpack-contrib/sass-loader/issues/556#issuecomment-381154009

'This should not be imported';
