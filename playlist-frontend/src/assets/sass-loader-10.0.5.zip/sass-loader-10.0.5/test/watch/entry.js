'use strict';

require('../scss/imports.scss');
