module.exports = { singleQuote: true };
